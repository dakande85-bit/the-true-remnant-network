import { MapPin } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";
import { directoryItems } from "@/data/directory";

export default function MapPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Map" title="Find Christian Work Near You" text="A simple map/discovery page. Later this can connect to Google Maps or Mapbox with real filtering." />
      <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr]">
        <aside className="card p-5">
          <input className="mb-3 w-full rounded-xl border p-4" placeholder="Search city or country..." />
          <select className="mb-3 w-full rounded-xl border p-4"><option>All Categories</option></select>
          <select className="mb-3 w-full rounded-xl border p-4"><option>All Languages</option></select>
          <button className="btn-primary w-full">Search Map</button>
        </aside>
        <div className="card relative min-h-[460px] overflow-hidden bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1400&auto=format&fit=crop')] bg-cover bg-center">
          <div className="absolute inset-0 bg-white/35" />
          <div className="absolute inset-0 p-8">
            {directoryItems.map((item, index) => <div key={item.slug} className="absolute rounded-full bg-ink p-2 text-white shadow-soft" style={{ left: `${20 + index * 16}%`, top: `${25 + (index % 3) * 20}%` }} title={item.name}><MapPin className="h-6 w-6 text-gold" /></div>)}
          </div>
        </div>
      </div>
    </section>
  );
}
