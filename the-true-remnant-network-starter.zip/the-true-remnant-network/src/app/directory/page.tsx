import { DirectoryCard } from "@/components/directory-card";
import { SectionHeading } from "@/components/section-heading";
import { directoryItems } from "@/data/directory";

export default function DirectoryPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Directory" title="Verified Christian Directory" text="Find churches, teachers, charities, missions, events, resources and Christian organisations reviewed before listing." />
      <div className="card mb-8 grid gap-3 p-4 md:grid-cols-4">
        <input className="rounded-xl border p-3 md:col-span-2" placeholder="Search by name, city, country or topic..." />
        <select className="rounded-xl border p-3"><option>All Categories</option></select>
        <select className="rounded-xl border p-3"><option>All Verification Levels</option></select>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{directoryItems.map((item) => <DirectoryCard key={item.slug} item={item} />)}</div>
    </section>
  );
}
