import Link from "next/link";
import { notFound } from "next/navigation";
import { ExternalLink, MapPin, ShieldCheck } from "lucide-react";
import { directoryItems } from "@/data/directory";

export function generateStaticParams() {
  return directoryItems.map((item) => ({ slug: item.slug }));
}

export default function DirectoryProfilePage({ params }: { params: { slug: string } }) {
  const item = directoryItems.find((entry) => entry.slug === params.slug);
  if (!item) return notFound();

  return (
    <section className="container-page py-16">
      <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <div className="badge mb-4">{item.category}</div>
          <h1 className="font-display text-5xl font-bold">{item.name}</h1>
          <p className="mt-4 flex items-center gap-2 text-ink/60"><MapPin className="h-5 w-5" />{item.city}, {item.country}</p>
          <p className="mt-6 text-lg leading-8 text-ink/75">{item.bio}</p>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {item.websiteUrl && <a className="btn-primary" href={item.websiteUrl}>Website <ExternalLink className="ml-2 h-4 w-4" /></a>}
            {item.youtubeUrl && <a className="btn-secondary" href={item.youtubeUrl}>YouTube <ExternalLink className="ml-2 h-4 w-4" /></a>}
            {item.donationUrl && <a className="btn-secondary" href={item.donationUrl}>External Giving Link <ExternalLink className="ml-2 h-4 w-4" /></a>}
          </div>
        </div>
        <aside className="card overflow-hidden">
          <div className="h-72 bg-cover bg-center" style={{ backgroundImage: `url(${item.imageUrl})` }} />
          <div className="p-6">
            <div className="flex items-center gap-2 font-black text-gold"><ShieldCheck /> {item.status}</div>
            <p className="mt-3 text-sm leading-6 text-ink/70">Verification means this profile has been reviewed according to the current The True Remnant process. It is not a claim that every teaching or action is endorsed forever.</p>
          </div>
        </aside>
      </div>
      <div className="card mt-10 p-8">
        <h2 className="font-display text-3xl font-bold">Statement of Faith / Notes</h2>
        <p className="mt-4 leading-8 text-ink/70">{item.statementOfFaith || "Statement of faith will be added after review."}</p>
        <Link href="/verification" className="mt-6 inline-flex font-black text-gold">View verification process →</Link>
      </div>
    </section>
  );
}
