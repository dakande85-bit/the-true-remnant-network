import { Calendar } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

const events = [
  { title: "Wednesday Prayer Night", city: "Tenerife", date: "Every Wednesday", type: "Prayer" },
  { title: "Awakening Conference", city: "London", date: "Coming Soon", type: "Conference" },
  { title: "Street Evangelism Training", city: "Manchester", date: "Coming Soon", type: "Training" }
];

export default function EventsPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Events" title="Christian Events" text="Prayer nights, conferences, worship nights, evangelism training and mission events from reviewed organisations." />
      <div className="grid gap-6 md:grid-cols-3">{events.map((event) => <article className="card p-6" key={event.title}><Calendar className="mb-4 h-8 w-8 text-gold" /><div className="badge mb-3">{event.type}</div><h2 className="font-display text-2xl font-bold">{event.title}</h2><p className="mt-2 text-ink/60">{event.city} • {event.date}</p><a className="mt-5 inline-flex font-black text-gold" href="#">External event link →</a></article>)}</div>
    </section>
  );
}
