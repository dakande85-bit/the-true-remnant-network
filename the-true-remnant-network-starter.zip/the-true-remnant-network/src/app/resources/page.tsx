import { ResourceTabs } from "@/components/resource-tabs";

export default function ResourcesPage() {
  return (
    <>
      <section className="bg-ink py-16 text-white">
        <div className="container-page">
          <div className="max-w-3xl">
            <div className="badge mb-4 border-white/20 bg-white/10 text-white">Resources</div>
            <h1 className="font-display text-5xl font-bold">Reading List, Worship Music, Audio Teaching & Tools</h1>
            <p className="mt-5 text-lg leading-8 text-white/70">Curated books, music, teaching audio, devotionals and Bible tools to help believers grow in faith and discernment.</p>
          </div>
        </div>
      </section>
      <section className="container-page -mt-8 pb-16">
        <ResourceTabs />
      </section>
    </>
  );
}
