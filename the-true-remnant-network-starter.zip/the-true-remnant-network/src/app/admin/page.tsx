import { SectionHeading } from "@/components/section-heading";

const modules = ["Applications", "Directory Profiles", "Verification Queue", "Resources", "Podcast Episodes", "Events", "Map Locations", "Reports / Concerns"];

export default function AdminPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Admin MVP" title="Admin Structure" text="Placeholder admin dashboard. Later this should be protected with Supabase Auth and role-based access." />
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">{modules.map((module) => <div className="card p-6" key={module}><div className="badge mb-3">Admin</div><h2 className="font-display text-xl font-bold">{module}</h2><p className="mt-3 text-sm leading-6 text-ink/60">Manage and review {module.toLowerCase()}.</p></div>)}</div>
    </section>
  );
}
