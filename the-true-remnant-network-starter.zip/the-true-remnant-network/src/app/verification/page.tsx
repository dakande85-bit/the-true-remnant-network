import { ShieldCheck } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

const steps = [
  "Identity and public information checked",
  "Statement of faith reviewed",
  "Leadership/accountability checked where possible",
  "Official links confirmed",
  "Donation links must go to official external pages",
  "Concerns can trigger Under Review status"
];

export default function VerificationPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Verification" title="What verification means" text="A clear, simple review process for the MVP. This can become more formal later with reviewers and audit logs." />
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{steps.map((step, index) => <div className="card p-6" key={step}><ShieldCheck className="mb-4 h-8 w-8 text-gold" /><div className="badge mb-3">Step {index + 1}</div><h2 className="font-display text-xl font-bold">{step}</h2></div>)}</div>
    </section>
  );
}
