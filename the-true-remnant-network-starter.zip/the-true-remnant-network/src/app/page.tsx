import Link from "next/link";
import { BookOpen, Calendar, Church, Globe2, HeartHandshake, MapPin, Mic2, Music, Users } from "lucide-react";
import { DirectoryCard } from "@/components/directory-card";
import { SectionHeading } from "@/components/section-heading";
import { directoryItems } from "@/data/directory";
import { podcastEpisodes } from "@/data/podcast";

const categories = [
  ["Churches", Church], ["Teachers", BookOpen], ["Ministries", Users], ["Charities", HeartHandshake], ["Missions", Globe2], ["Events", Calendar], ["Music & Books", Music]
];

export default function HomePage() {
  const latest = podcastEpisodes[0];
  return (
    <>
      <section className="hero-gradient py-20 text-white">
        <div className="container-page grid items-center gap-12 lg:grid-cols-2">
          <div>
            <div className="badge mb-5 border-white/20 bg-white/10 text-white">Christian Trust Network</div>
            <h1 className="font-display text-5xl font-black leading-tight md:text-7xl">Connecting Believers. Building <span className="text-gold">His Kingdom.</span></h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-white/78">Discover reviewed Christian churches, teachers, ministries, missions, resources and testimonies around the world.</p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/podcast" className="btn-primary"><Mic2 className="mr-2 h-5 w-5" /> Watch the Podcast</Link>
              <Link href="/directory" className="btn-secondary"><Users className="mr-2 h-5 w-5" /> Explore Directory</Link>
            </div>
          </div>
          <div className="card min-h-[420px] bg-[url('https://images.unsplash.com/photo-1477346611705-65d1883cee1e?q=80&w=1400&auto=format&fit=crop')] bg-cover bg-center" />
        </div>
      </section>

      <section className="container-page py-14">
        <div className="grid gap-4 md:grid-cols-4 lg:grid-cols-7">
          {categories.map(([label, Icon]) => <Link href="/directory" key={String(label)} className="card flex flex-col items-center gap-3 p-5 text-center font-black hover:bg-cream"><Icon className="h-7 w-7 text-gold" />{label as string}</Link>)}
        </div>
      </section>

      <section className="container-page grid gap-8 py-12 lg:grid-cols-2">
        <div>
          <SectionHeading title="Find trusted Christian work near you or around the world" text="Search for churches, ministries, missionaries, charities and Christian organisations by location and category." />
          <div className="card p-5">
            <input className="mb-3 w-full rounded-xl border p-4" placeholder="Enter city, country or keyword..." />
            <div className="flex gap-3"><select className="w-full rounded-xl border p-4"><option>All Categories</option></select><Link href="/map" className="btn-primary">Search</Link></div>
            <Link href="/map" className="mt-4 flex items-center gap-2 text-sm font-bold"><MapPin className="h-4 w-4" /> Explore on the map</Link>
          </div>
        </div>
        <div className="card min-h-[340px] bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1400&auto=format&fit=crop')] bg-cover bg-center" />
      </section>

      <section className="container-page py-12">
        <SectionHeading eyebrow="Featured" title="Featured This Week" text="A starting selection of reviewed churches, teachers, missions and charities." />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">{directoryItems.map((item) => <DirectoryCard key={item.slug} item={item} />)}</div>
      </section>

      <section className="container-page grid gap-8 py-12 lg:grid-cols-2">
        <div className="card bg-ink p-8 text-white">
          <div className="badge mb-4 border-white/20 bg-white/10 text-white">Latest Podcast</div>
          <h2 className="font-display text-3xl font-bold">{latest.title}</h2>
          <p className="mt-2 text-white/70">with {latest.guest}</p>
          <p className="mt-4 leading-7 text-white/70">{latest.summary}</p>
          <Link href="/podcast" className="btn-primary mt-6">Watch on YouTube</Link>
        </div>
        <div className="card bg-cream p-8">
          <div className="badge mb-4">True Remnant Clothing</div>
          <h2 className="font-display text-3xl font-bold">Stand firm. Stay faithful.</h2>
          <p className="mt-4 leading-7 text-ink/70">A small clothing section can support the wider Christian media and network mission without turning the platform into a marketplace.</p>
          <Link href="/clothing" className="btn-secondary mt-6">View Clothing</Link>
        </div>
      </section>
    </>
  );
}
