import { PlayCircle } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";
import { podcastEpisodes } from "@/data/podcast";

export default function PodcastPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Podcast" title="The True Remnant Podcast" text="Conversations with Christian teachers, pastors, missionaries, worship leaders, authors and faithful witnesses." />
      <div className="grid gap-6 md:grid-cols-2">{podcastEpisodes.map((episode) => (
        <article key={episode.slug} className="card overflow-hidden">
          <div className="relative h-64 bg-cover bg-center" style={{ backgroundImage: `url(${episode.thumbnailUrl})` }}><div className="absolute inset-0 flex items-center justify-center bg-ink/30"><PlayCircle className="h-16 w-16 text-white" /></div></div>
          <div className="p-6"><div className="badge mb-3">{episode.topics.join(" • ")}</div><h2 className="font-display text-2xl font-bold">{episode.title}</h2><p className="mt-2 font-semibold text-ink/60">with {episode.guest}</p><p className="mt-4 leading-7 text-ink/70">{episode.summary}</p><a href={episode.youtubeUrl} className="btn-primary mt-5">Watch on YouTube</a></div>
        </article>
      ))}</div>
    </section>
  );
}
