import { SectionHeading } from "@/components/section-heading";

export default function SubmitPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Submit" title="Submit a Ministry, Church or Resource" text="Applications are manually reviewed before anything is listed. This form is the front door for the verification process." />
      <form className="card grid gap-5 p-6 md:grid-cols-2">
        <input className="rounded-xl border p-4" placeholder="Name of person / ministry / organisation" />
        <select className="rounded-xl border p-4"><option>Category</option><option>Church</option><option>Teacher</option><option>Mission</option><option>Charity</option><option>Music</option><option>Book</option><option>Event</option></select>
        <input className="rounded-xl border p-4" placeholder="City" />
        <input className="rounded-xl border p-4" placeholder="Country" />
        <input className="rounded-xl border p-4" placeholder="Website URL" />
        <input className="rounded-xl border p-4" placeholder="YouTube / social URL" />
        <textarea className="rounded-xl border p-4 md:col-span-2" rows={5} placeholder="Bio / mission / why this should be listed" />
        <textarea className="rounded-xl border p-4 md:col-span-2" rows={5} placeholder="Statement of faith / references / accountability" />
        <button type="button" className="btn-primary md:col-span-2">Submit for Review</button>
      </form>
    </section>
  );
}
