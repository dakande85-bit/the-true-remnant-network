import { Shirt } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

export default function ClothingPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="True Remnant Clothing" title="Stand firm. Stay faithful." text="A simple clothing section linking to your external shop. Keep this small at first so the network stays focused on Christian content and verification." />
      <div className="card grid overflow-hidden lg:grid-cols-2">
        <div className="p-10"><Shirt className="mb-5 h-12 w-12 text-gold" /><h2 className="font-display text-4xl font-bold">Faith-centred clothing with purpose.</h2><p className="mt-5 leading-8 text-ink/70">Use this page to link to the True Remnant Clothing Shopify/Gelato/Printful store. Products can support brand visibility and help fund the podcast/network mission.</p><a className="btn-primary mt-8" href="#">Open Shop</a></div>
        <div className="min-h-[420px] bg-[url('https://images.unsplash.com/photo-1523381294911-8d3cead13475?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center" />
      </div>
    </section>
  );
}
