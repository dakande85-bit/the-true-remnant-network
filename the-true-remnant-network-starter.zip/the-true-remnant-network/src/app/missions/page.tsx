import { DirectoryCard } from "@/components/directory-card";
import { SectionHeading } from "@/components/section-heading";
import { directoryItems } from "@/data/directory";

export default function MissionsPage() {
  const missions = directoryItems.filter((item) => item.category === "Mission" || item.category === "Charity");
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="Missions" title="Support Kingdom Work" text="Mission and charity profiles with external support links only. The site does not process donations in the MVP." />
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{missions.map((item) => <DirectoryCard key={item.slug} item={item} />)}</div>
    </section>
  );
}
