import { SectionHeading } from "@/components/section-heading";

export default function AboutPage() {
  return (
    <section className="container-page py-16">
      <SectionHeading eyebrow="About" title="A Christian network built for trust" text="The True Remnant exists to connect believers with faithful Christian content, churches, teachers, missions and resources." />
      <div className="card p-8 text-lg leading-8 text-ink/75">
        <p>The platform starts simple: a podcast hub, a reviewed directory, resource tabs, a map, and external links to official ministry pages. The aim is to help people discover trustworthy Christian work without turning the site into a payment marketplace.</p>
        <p className="mt-6">Listings are reviewed before publishing. Verification is a practical trust process, not a claim that any person or organisation is perfect or endorsed forever.</p>
      </div>
    </section>
  );
}
