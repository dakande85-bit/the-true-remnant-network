import { ResourceItem } from "./types";

export const resources: ResourceItem[] = [
  {
    id: "purpose-driven-life",
    title: "The Purpose Driven Life",
    creator: "Rick Warren",
    type: "book",
    category: "Spiritual Growth",
    topic: "Purpose",
    description: "A Christian reading-list resource about living with God-given purpose.",
    externalUrl: "https://example.com/book",
    imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "spiritual-warfare-every-christian",
    title: "Spiritual Warfare for Every Christian",
    creator: "Derek Prince",
    type: "book",
    category: "Spiritual Warfare",
    topic: "Deliverance",
    description: "A recommended book for understanding spiritual warfare from a biblical perspective.",
    externalUrl: "https://example.com/book",
    imageUrl: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "way-maker-live",
    title: "Way Maker Live",
    creator: "Leeland",
    type: "music",
    category: "Worship",
    topic: "Praise",
    description: "Worship audio/music recommendation for prayer and praise.",
    externalUrl: "https://youtube.com",
    imageUrl: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "goodness-of-god",
    title: "Goodness of God",
    creator: "Bethel Music",
    type: "music",
    category: "Worship",
    topic: "Thanksgiving",
    description: "A worship music resource focused on God's faithfulness.",
    externalUrl: "https://youtube.com",
    imageUrl: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "prayer-teaching-series",
    title: "Prayer That Changes Things",
    creator: "The True Remnant Podcast",
    type: "teaching",
    category: "Teaching Audio",
    topic: "Prayer",
    description: "Audio teaching series on prayer, obedience and faith.",
    externalUrl: "https://youtube.com",
    imageUrl: "https://images.unsplash.com/photo-1504052434569-70ad5836ab65?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "bible-apps-tools",
    title: "Bible Study Tools",
    creator: "The True Remnant",
    type: "tool",
    category: "Bible Apps & Tools",
    topic: "Study",
    description: "A list of useful Bible study apps, websites and tools.",
    externalUrl: "https://example.com/tools",
    imageUrl: "https://images.unsplash.com/photo-1490730141103-6cac27aaab94?q=80&w=800&auto=format&fit=crop"
  }
];
