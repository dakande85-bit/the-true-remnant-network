import { PodcastEpisode } from "./types";

export const podcastEpisodes: PodcastEpisode[] = [
  {
    slug: "faith-that-moves-mountains",
    title: "Faith That Moves Mountains",
    guest: "Missionary John Carter",
    summary: "An inspiring conversation about faith, obedience and seeing God move in impossible places.",
    youtubeUrl: "https://youtube.com",
    thumbnailUrl: "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?q=80&w=1200&auto=format&fit=crop",
    topics: ["Faith", "Missions", "Prayer"]
  },
  {
    slug: "standing-firm-in-faith",
    title: "Standing Firm in Faith",
    guest: "Pastor Daniel Wilson",
    summary: "A practical discussion on discipleship, endurance and living faithfully in a confused world.",
    youtubeUrl: "https://youtube.com",
    thumbnailUrl: "https://images.unsplash.com/photo-1478737270239-2f02b77fc618?q=80&w=1200&auto=format&fit=crop",
    topics: ["Discipleship", "Teaching", "Church"]
  }
];
