import { DirectoryItem } from "./types";

export const directoryItems: DirectoryItem[] = [
  {
    slug: "tenerife-family-church",
    name: "Tenerife Family Church",
    category: "Church",
    city: "Las Chafiras",
    country: "Spain",
    description: "English-speaking Christian church serving families and believers in Tenerife South.",
    bio: "A local church community centred on worship, Bible teaching, prayer, fellowship and family ministry.",
    status: "Recommended",
    language: ["English"],
    websiteUrl: "https://example.com",
    youtubeUrl: "https://youtube.com",
    donationUrl: "https://example.com/give",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?q=80&w=1200&auto=format&fit=crop",
    statementOfFaith: "Jesus Christ is Lord, the Bible is the Word of God, salvation is by grace through faith.",
    coordinates: { lat: 28.0407, lng: -16.6121 }
  },
  {
    slug: "pastor-daniel-wilson",
    name: "Pastor Daniel Wilson",
    category: "Teacher",
    city: "Manchester",
    country: "United Kingdom",
    description: "Bible teacher focused on discipleship, prayer and spiritual formation.",
    bio: "A Christian teacher and pastor sharing biblical teaching for everyday discipleship and obedience.",
    status: "Verified",
    language: ["English"],
    websiteUrl: "https://example.com",
    youtubeUrl: "https://youtube.com",
    imageUrl: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?q=80&w=1200&auto=format&fit=crop",
    coordinates: { lat: 53.4808, lng: -2.2426 }
  },
  {
    slug: "brazil-mission-project",
    name: "Brazil Mission Project",
    category: "Mission",
    city: "São Paulo",
    country: "Brazil",
    description: "Mission outreach supporting evangelism, discipleship and practical care in Brazil.",
    bio: "A mission project connecting local believers with outreach, prayer, evangelism and practical support.",
    status: "Reviewed",
    language: ["Portuguese", "English"],
    donationUrl: "https://example.com/support-brazil",
    imageUrl: "https://images.unsplash.com/photo-1483729558449-99ef09a8c325?q=80&w=1200&auto=format&fit=crop",
    coordinates: { lat: -23.5505, lng: -46.6333 }
  },
  {
    slug: "hope-house-childrens-home",
    name: "Hope House Children's Home",
    category: "Charity",
    city: "Nairobi",
    country: "Kenya",
    description: "Christian charity supporting children, family care and community outreach.",
    bio: "A charity serving vulnerable children with care, education, prayer and practical support.",
    status: "Listed",
    language: ["English"],
    donationUrl: "https://example.com/donate",
    imageUrl: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=1200&auto=format&fit=crop",
    coordinates: { lat: -1.2921, lng: 36.8219 }
  }
];
