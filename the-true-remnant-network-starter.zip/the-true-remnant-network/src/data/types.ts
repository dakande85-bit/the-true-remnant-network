export type DirectoryCategory = "Church" | "Teacher" | "Ministry" | "Charity" | "Mission" | "Event" | "Music" | "Book";
export type VerificationStatus = "Listed" | "Reviewed" | "Verified" | "Recommended" | "Under Review";

export type DirectoryItem = {
  slug: string;
  name: string;
  category: DirectoryCategory;
  city: string;
  country: string;
  description: string;
  bio: string;
  status: VerificationStatus;
  language: string[];
  websiteUrl?: string;
  youtubeUrl?: string;
  donationUrl?: string;
  imageUrl: string;
  statementOfFaith?: string;
  relatedPodcastSlug?: string;
  coordinates?: { lat: number; lng: number };
};

export type ResourceItem = {
  id: string;
  title: string;
  creator: string;
  type: "book" | "music" | "teaching" | "devotional" | "tool";
  category: string;
  topic: string;
  description: string;
  externalUrl?: string;
  imageUrl: string;
};

export type PodcastEpisode = {
  slug: string;
  title: string;
  guest: string;
  summary: string;
  youtubeUrl: string;
  thumbnailUrl: string;
  topics: string[];
};
