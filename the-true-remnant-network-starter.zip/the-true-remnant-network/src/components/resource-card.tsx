import { ExternalLink, Heart, Play } from "lucide-react";
import { ResourceItem } from "@/data/types";

export function ResourceCard({ item }: { item: ResourceItem }) {
  const isAudio = item.type === "music" || item.type === "teaching";
  return (
    <article className="card overflow-hidden">
      <div className="relative h-44 bg-cover bg-center" style={{ backgroundImage: `url(${item.imageUrl})` }}>
        {isAudio && <div className="absolute inset-0 flex items-center justify-center"><div className="flex h-14 w-14 items-center justify-center rounded-full bg-white/90"><Play className="ml-1 h-6 w-6 text-gold" /></div></div>}
      </div>
      <div className="p-5">
        <div className="badge mb-3">{item.category}</div>
        <h3 className="font-display text-xl font-bold">{item.title}</h3>
        <p className="mt-1 text-sm font-semibold text-ink/60">{item.creator}</p>
        <p className="mt-3 text-sm leading-6 text-ink/70">{item.description}</p>
        <div className="mt-5 flex items-center justify-between">
          <a href={item.externalUrl || "#"} className="text-sm font-black text-ink">Open <ExternalLink className="ml-1 inline h-4 w-4" /></a>
          <button aria-label="Save" className="rounded-full border p-2"><Heart className="h-4 w-4" /></button>
        </div>
      </div>
    </article>
  );
}
