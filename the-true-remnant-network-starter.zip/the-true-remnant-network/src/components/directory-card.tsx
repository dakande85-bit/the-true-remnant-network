import Link from "next/link";
import { MapPin, ShieldCheck } from "lucide-react";
import { DirectoryItem } from "@/data/types";

export function DirectoryCard({ item }: { item: DirectoryItem }) {
  return (
    <Link href={`/directory/${item.slug}`} className="card block overflow-hidden transition hover:-translate-y-1">
      <div className="h-40 bg-cover bg-center" style={{ backgroundImage: `url(${item.imageUrl})` }} />
      <div className="p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <span className="badge">{item.category}</span>
          <span className="flex items-center gap-1 text-xs font-bold text-gold"><ShieldCheck className="h-4 w-4" />{item.status}</span>
        </div>
        <h3 className="font-display text-xl font-bold">{item.name}</h3>
        <p className="mt-2 text-sm leading-6 text-ink/70">{item.description}</p>
        <div className="mt-4 flex items-center gap-2 text-sm text-ink/60"><MapPin className="h-4 w-4" />{item.city}, {item.country}</div>
      </div>
    </Link>
  );
}
