export function SectionHeading({ eyebrow, title, text }: { eyebrow?: string; title: string; text?: string }) {
  return (
    <div className="mb-8 max-w-3xl">
      {eyebrow && <div className="badge mb-3">{eyebrow}</div>}
      <h2 className="font-display text-3xl font-bold text-ink md:text-4xl">{title}</h2>
      {text && <p className="mt-3 text-lg leading-8 text-ink/70">{text}</p>}
    </div>
  );
}
