import Link from "next/link";
import { Cross, Search } from "lucide-react";

const nav = [
  ["Home", "/"],
  ["Podcast", "/podcast"],
  ["Directory", "/directory"],
  ["Map", "/map"],
  ["Missions", "/missions"],
  ["Events", "/events"],
  ["Resources", "/resources"],
  ["Clothing", "/clothing"],
  ["About", "/about"]
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-ink/95 text-white backdrop-blur">
      <div className="container-page flex h-20 items-center justify-between gap-6">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-full border border-gold/40 bg-gold/15">
            <Cross className="h-6 w-6 text-gold" />
          </div>
          <div>
            <div className="font-display text-xl font-bold tracking-wide">THE TRUE REMNANT</div>
            <div className="text-[10px] font-black uppercase tracking-[0.42em] text-gold">Network</div>
          </div>
        </Link>
        <nav className="hidden items-center gap-6 text-sm font-semibold lg:flex">
          {nav.map(([label, href]) => <Link key={href} href={href} className="hover:text-gold">{label}</Link>)}
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/directory" aria-label="Search" className="hidden md:flex"><Search /></Link>
          <Link href="/submit" className="btn-primary">Submit Ministry</Link>
        </div>
      </div>
    </header>
  );
}
