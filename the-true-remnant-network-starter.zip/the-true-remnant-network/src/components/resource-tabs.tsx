"use client";

import { useMemo, useState } from "react";
import { BookOpen, Grid2X2, Headphones, Music, Smartphone, Sparkles } from "lucide-react";
import { resources } from "@/data/resources";
import { ResourceCard } from "./resource-card";

const tabs = [
  { key: "all", label: "All Resources", icon: Grid2X2 },
  { key: "book", label: "Reading List (Books)", icon: BookOpen },
  { key: "music", label: "Audio (Music)", icon: Music },
  { key: "teaching", label: "Teachings (Audio)", icon: Headphones },
  { key: "devotional", label: "Devotionals", icon: Sparkles },
  { key: "tool", label: "Bible Apps & Tools", icon: Smartphone }
] as const;

export function ResourceTabs() {
  const [active, setActive] = useState<(typeof tabs)[number]["key"]>("all");
  const filtered = useMemo(() => active === "all" ? resources : resources.filter((item) => item.type === active), [active]);

  return (
    <section>
      <div className="card mb-8 grid gap-2 p-2 md:grid-cols-3 lg:grid-cols-6">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.key;
          return (
            <button key={tab.key} onClick={() => setActive(tab.key)} className={`flex items-center justify-center gap-2 rounded-2xl px-4 py-4 text-sm font-black transition ${isActive ? "bg-gold text-white" : "hover:bg-cream"}`}>
              <Icon className="h-5 w-5" />
              {tab.label}
            </button>
          );
        })}
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((item) => <ResourceCard key={item.id} item={item} />)}
      </div>
    </section>
  );
}
