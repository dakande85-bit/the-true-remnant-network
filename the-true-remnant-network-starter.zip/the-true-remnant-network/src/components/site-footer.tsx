import Link from "next/link";
import { Cross } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="bg-ink py-12 text-white">
      <div className="container-page grid gap-10 md:grid-cols-4">
        <div>
          <div className="mb-4 flex items-center gap-3">
            <Cross className="text-gold" />
            <div>
              <div className="font-display text-xl font-bold">The True Remnant</div>
              <div className="text-xs uppercase tracking-[0.3em] text-gold">Network</div>
            </div>
          </div>
          <p className="text-sm text-white/70">Connecting believers with reviewed Christian voices, churches, missions and resources.</p>
        </div>
        <FooterColumn title="Explore" links={[["Podcast", "/podcast"], ["Directory", "/directory"], ["Map", "/map"], ["Resources", "/resources"]]} />
        <FooterColumn title="Support" links={[["Submit Ministry", "/submit"], ["Missions", "/missions"], ["Clothing", "/clothing"], ["Verification", "/verification"]]} />
        <div>
          <h3 className="mb-3 font-bold text-gold">Scripture</h3>
          <p className="text-sm text-white/70">“Contend for the faith once delivered to the saints.”</p>
          <p className="mt-2 text-sm font-bold">Jude 1:3</p>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, links }: { title: string; links: string[][] }) {
  return <div><h3 className="mb-3 font-bold text-gold">{title}</h3><div className="grid gap-2 text-sm text-white/70">{links.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}</div></div>;
}
