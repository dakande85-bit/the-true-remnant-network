# The True Remnant

A simple MVP for a trusted Christian content and ministry network.

The platform is designed to start simple:

- Podcast hub with YouTube episodes
- Verified Christian directory for churches, teachers, ministers, charities, missionaries, music, books, and events
- Resource area with tabs for reading list, worship/music audio, teachings, devotionals, and tools
- Map/discovery page for local Christian organisations
- Missions/support page using external links only
- True Remnant Clothing page for a small shop link
- Submit ministry form for manual review
- Admin-ready data model and verification workflow

## Important MVP Rule

This project does **not** process donations or marketplace payments. Support links go externally to official ministry, charity, church, GiveSendGo, GoFundMe, PayPal, Stripe, Shopify, or other approved pages.

## Recommended Stack

- Next.js App Router
- TypeScript
- Tailwind CSS
- Supabase later for database/auth/admin
- YouTube embeds for podcast/video
- External URLs for donations, books, music, clothing, and events

## Pages

```txt
/
/podcast
/directory
/directory/[slug]
/resources
/map
/missions
/events
/clothing
/submit
/about
/verification
/admin
```

## Local Development

```bash
npm install
npm run dev
```

## Environment

Copy `.env.example` to `.env.local` when you connect Supabase and APIs.

```bash
cp .env.example .env.local
```
