-- Future Supabase schema for The True Remnant
-- Keep payments out of the database for MVP. Store only external support URLs.

create type verification_status as enum ('Listed', 'Reviewed', 'Verified', 'Recommended', 'Under Review', 'Removed');
create type directory_category as enum ('Church', 'Teacher', 'Ministry', 'Charity', 'Mission', 'Event', 'Music', 'Book');

create table if not exists directory_profiles (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  category directory_category not null,
  city text,
  country text,
  description text,
  bio text,
  status verification_status default 'Listed',
  languages text[] default '{}',
  website_url text,
  youtube_url text,
  donation_url text,
  image_url text,
  statement_of_faith text,
  latitude numeric,
  longitude numeric,
  approved boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  creator text,
  type text check (type in ('book', 'music', 'teaching', 'devotional', 'tool')),
  category text,
  topic text,
  description text,
  external_url text,
  image_url text,
  approved boolean default false,
  created_at timestamptz default now()
);

create table if not exists podcast_episodes (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  guest text,
  summary text,
  youtube_url text,
  thumbnail_url text,
  topics text[] default '{}',
  published_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists applications (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text,
  city text,
  country text,
  website_url text,
  social_url text,
  bio text,
  statement_of_faith text,
  submitter_email text,
  status text default 'pending',
  created_at timestamptz default now()
);

create table if not exists concern_reports (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references directory_profiles(id),
  reporter_email text,
  concern text not null,
  status text default 'open',
  created_at timestamptz default now()
);
