# Codex Build Prompt

Build the The True Remnant MVP from this repo.

Project purpose:
A trusted Christian content and ministry network. It has a podcast hub, reviewed Christian directory, resources tabs for reading list/books and audio/music, map discovery, missions/support pages with external links only, and True Remnant Clothing as a simple external shop page.

Hard rules:
- Do not build a payment marketplace.
- Do not process donations on-site.
- Donation/support buttons are external links only.
- Do not publicly call churches false; use verification statuses and review language.
- Keep the design premium, clean, biblical, warm, and trustworthy.

Build priorities:
1. Polish responsive UI.
2. Make directory search/filter work client-side using seed data.
3. Make resource tabs work cleanly for Books, Music, Teaching Audio, Devotionals, Tools.
4. Make submit form capture data locally first or prepare Supabase insert later.
5. Add real Supabase integration only after the UI is stable.
6. Add admin authentication later.

Pages:
- Home
- Podcast
- Directory
- Directory profile
- Resources
- Map
- Missions
- Events
- Clothing
- Submit
- About
- Verification
- Admin placeholder
