# Verification Workflow

## Public Statuses

- Listed: known organisation/resource added with basic information
- Reviewed: public details checked
- Verified: identity, doctrine, accountability and links reviewed
- Recommended: personally known, interviewed or strongly referenced
- Under Review: concerns raised or details need re-checking

## Internal Checklist

1. Confirm real identity or official organisation name.
2. Confirm website/social links are official.
3. Review statement of faith.
4. Review leadership/accountability structure where possible.
5. Confirm whether donation/support links are external and official.
6. Add notes to admin record.
7. Publish only if approved.

## Safer Public Language

Avoid saying “true man of God” as a legal/public label. Prefer:

> Reviewed Christian leader / ministry / organisation.

Avoid saying “false church” unless dealing with a private review note and clear evidence. Prefer:

> Not listed, not verified, or removed after review.
