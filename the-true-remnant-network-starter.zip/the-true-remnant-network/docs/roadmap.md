# Roadmap

## Phase 1 — Simple Launch

- Home
- Podcast
- Directory
- Profile pages
- Resources tabs: books, music, teaching audio, devotionals, tools
- Submit ministry form
- Basic map placeholder
- True Remnant Clothing link

## Phase 2 — Real Data

- Supabase tables
- Admin authentication
- Application approval workflow
- Upload images
- Rich profile editing

## Phase 3 — Discovery

- Real map integration
- Search and filters
- Language filters
- Denomination/stream filters
- Country/city pages

## Phase 4 — Trust Layer

- Review notes
- Reviewer roles
- Concern reports
- Audit log
- Annual re-verification

## Phase 5 — Media Expansion

- Podcast series pages
- Guest profiles connected to episodes
- Clips/shorts library
- Newsletter
- Sponsorship/affiliate placements
