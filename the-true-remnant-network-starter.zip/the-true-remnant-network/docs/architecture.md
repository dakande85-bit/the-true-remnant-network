# Architecture

## MVP Architecture

```txt
Next.js App Router
  src/app        pages and routes
  src/components shared UI
  src/data       seed data for MVP
  src/lib        utilities later
  docs           build notes and product planning
  supabase       schema and future migrations
```

## No Marketplace Payments

The site should not hold funds at MVP stage. All support/donation links are external links.

## Future Database Tables

- profiles
- categories
- podcast_episodes
- resources
- events
- applications
- verification_reviews
- concern_reports
- external_links

## Future Roles

- owner
- admin
- reviewer
- editor
- ministry_owner
