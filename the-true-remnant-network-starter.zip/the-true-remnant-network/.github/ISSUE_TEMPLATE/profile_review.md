---
name: Profile review
description: Review a church, ministry, teacher, charity, mission, resource or event
title: "Profile review: "
labels: ["verification", "profile-review"]
---

## Profile Name

## Category

## Website / Official Links

## Statement of Faith Notes

## References / Accountability

## Support / Donation Link

## Recommendation

- [ ] Listed
- [ ] Reviewed
- [ ] Verified
- [ ] Recommended
- [ ] Under Review
- [ ] Do not list
