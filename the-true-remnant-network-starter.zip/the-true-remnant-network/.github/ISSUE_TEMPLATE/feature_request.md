---
name: Feature request
description: Suggest a feature for The True Remnant
title: "Feature: "
labels: ["feature"]
---

## Goal

## User Story

As a visitor/admin/reviewer, I want to...

## Acceptance Criteria

- [ ]
- [ ]
- [ ]
