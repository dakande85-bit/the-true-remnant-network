import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#081521",
        navy: "#0B1D2C",
        gold: "#C9962C",
        cream: "#F7F1E5",
        mist: "#EEF4F4"
      },
      fontFamily: {
        display: ["Georgia", "serif"],
        body: ["Inter", "system-ui", "sans-serif"]
      },
      boxShadow: {
        soft: "0 18px 50px rgba(8,21,33,0.10)"
      }
    }
  },
  plugins: []
};

export default config;
